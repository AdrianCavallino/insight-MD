package com.mitsuru.insight.information

class LoginInformation {
    public var email : String? = null
    public var password : String? = null
}