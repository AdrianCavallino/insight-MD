package com.mitsuru.insight.information

class RegisterInformation {
    public var name : String? = null
    public var username : String? = null
    public var email : String? = null
    public var password : String? = null
}